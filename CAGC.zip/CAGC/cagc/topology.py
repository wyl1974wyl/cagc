"""Operational topology analysis for directed confusion adjacency graphs."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .graph import ConfusionAdjacencyGraph


@dataclass(frozen=True)
class TopologyConfig:
    edge_threshold: float = 0.05
    symmetric_ratio: float = 0.5
    hub_in_degree: int = 10
    hub_ratio: float = 3.0


@dataclass(frozen=True)
class TopologyReport:
    labels: list[str]
    out_degree: np.ndarray
    in_degree: np.ndarray
    symmetric_pairs: list[tuple[int, int]]
    hubs: list[int]
    asymmetric_pairs: list[tuple[int, int]]
    topology: list[str]

    def as_dict(self, graph: ConfusionAdjacencyGraph) -> dict[str, object]:
        return {
            "classes": [
                {
                    "index": index,
                    "label": graph.labels[index],
                    "out_degree": int(self.out_degree[index]),
                    "in_degree": int(self.in_degree[index]),
                    "topology": self.topology[index],
                }
                for index in range(graph.num_classes)
            ],
            "symmetric_pairs": [
                {
                    "source": source,
                    "target": target,
                    "source_label": graph.labels[source],
                    "target_label": graph.labels[target],
                }
                for source, target in self.symmetric_pairs
            ],
            "asymmetric_pairs": [
                {
                    "source": source,
                    "target": target,
                    "source_label": graph.labels[source],
                    "target_label": graph.labels[target],
                }
                for source, target in self.asymmetric_pairs
            ],
            "hubs": [
                {"index": index, "label": graph.labels[index]}
                for index in self.hubs
            ],
        }


def analyze_topology(graph: ConfusionAdjacencyGraph, config: TopologyConfig | None = None) -> TopologyReport:
    config = config or TopologyConfig()
    adjacency = graph.adjacency_matrix()
    weights = graph.weights
    out_degree = adjacency.sum(axis=1).astype(np.int64)
    in_degree = adjacency.sum(axis=0).astype(np.int64)
    symmetric_pairs: list[tuple[int, int]] = []
    asymmetric_pairs: list[tuple[int, int]] = []
    for source in range(graph.num_classes):
        for target in range(source + 1, graph.num_classes):
            forward = bool(adjacency[source, target])
            backward = bool(adjacency[target, source])
            if forward and backward:
                ratio = min(weights[source, target], weights[target, source]) / max(
                    weights[source, target], weights[target, source]
                )
                if ratio >= config.symmetric_ratio:
                    symmetric_pairs.append((source, target))
        for target in range(graph.num_classes):
            if source == target:
                continue
            if weights[source, target] > config.edge_threshold and weights[target, source] <= config.edge_threshold:
                asymmetric_pairs.append((source, target))
    hubs = [
        index
        for index in range(graph.num_classes)
        if in_degree[index] >= config.hub_in_degree
        and in_degree[index] / max(int(out_degree[index]), 1) >= config.hub_ratio
    ]
    topology: list[str] = []
    symmetric_members = {item for pair in symmetric_pairs for item in pair}
    asymmetric_members = {item for pair in asymmetric_pairs for item in pair}
    hub_members = set(hubs)
    for index in range(graph.num_classes):
        memberships = []
        if int(out_degree[index]) == 0 and int(in_degree[index]) == 0:
            memberships.append("well_separated")
        if index in symmetric_members:
            memberships.append("symmetric_adjacency")
        if index in hub_members:
            memberships.append("hub_absorption")
        if index in asymmetric_members:
            memberships.append("asymmetric_transmission")
        if len(memberships) == 0:
            topology.append("residual_mixed")
        elif len(memberships) == 1:
            topology.append(memberships[0])
        else:
            topology.append("residual_mixed")
    return TopologyReport(
        labels=graph.labels,
        out_degree=out_degree,
        in_degree=in_degree,
        symmetric_pairs=symmetric_pairs,
        hubs=hubs,
        asymmetric_pairs=asymmetric_pairs,
        topology=topology,
    )


def topology_confidence(graph: ConfusionAdjacencyGraph, gate_strength: float) -> np.ndarray:
    values = np.zeros(graph.num_classes, dtype=np.float64)
    for source, targets in graph.out_neighbors.items():
        if not targets:
            values[source] = 0.0
            continue
        probabilities = graph.weights[source, targets]
        total = probabilities.sum()
        if total <= 0:
            values[source] = 0.0
            continue
        probabilities = probabilities / total
        entropy = -float(np.sum(probabilities * np.log(np.clip(probabilities, 1e-12, 1.0))))
        normalized_entropy = entropy / np.log(len(targets)) if len(targets) > 1 else 0.0
        values[source] = gate_strength * float(probabilities.max()) / (1.0 + normalized_entropy)
    return values

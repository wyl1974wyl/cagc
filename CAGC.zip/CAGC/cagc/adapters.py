"""Composable score adapters for cascading CAGC after existing test-time adaptation outputs."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F


class ScoreAdapter:
    def adapt_scores(self, scores: np.ndarray, context: dict[str, object] | None = None) -> np.ndarray:
        return np.asarray(scores, dtype=np.float64)


class IdentityAdapter(ScoreAdapter):
    pass


class ScoreFileAdapter(ScoreAdapter):
    def __init__(self, score_path: str | Path) -> None:
        self.score_path = Path(score_path)

    def adapt_scores(self, scores: np.ndarray, context: dict[str, object] | None = None) -> np.ndarray:
        payload = np.load(self.score_path, allow_pickle=False)
        if "scores" in payload:
            return payload["scores"].astype(np.float64)
        if "logits" in payload:
            logits = payload["logits"].astype(np.float64)
            logits = logits - logits.max(axis=1, keepdims=True)
            exp = np.exp(logits)
            return exp / exp.sum(axis=1, keepdims=True)
        raise ValueError("Score files must contain either scores or logits.")


class EntropyMinimizationAdapter(ScoreAdapter):
    def __init__(self, model: torch.nn.Module, lr: float = 1e-3, steps: int = 1) -> None:
        self.model = model
        self.lr = lr
        self.steps = steps

    def adapt_features(self, features: torch.Tensor) -> torch.Tensor:
        parameters = [parameter for parameter in self.model.parameters() if parameter.requires_grad]
        if not parameters:
            with torch.no_grad():
                return F.softmax(self.model(features), dim=-1)
        optimizer = torch.optim.Adam(parameters, lr=self.lr)
        self.model.train()
        for _ in range(self.steps):
            logits = self.model(features)
            probabilities = F.softmax(logits, dim=-1)
            loss = -(probabilities * torch.log(probabilities.clamp_min(1e-12))).sum(dim=-1).mean()
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
        self.model.eval()
        with torch.no_grad():
            return F.softmax(self.model(features), dim=-1)


@dataclass(frozen=True)
class AdapterSpec:
    method: str
    score_path: str | None = None


def build_adapter(spec: AdapterSpec) -> ScoreAdapter:
    normalized = spec.method.lower()
    if normalized in {"none", "identity", "baseline"}:
        return IdentityAdapter()
    if normalized in {"tpt", "gs-bias", "dpe", "tda", "sca", "pta", "batclip", "tent"}:
        if spec.score_path is None:
            raise ValueError(f"{spec.method} requires a score_path containing baseline output scores.")
        return ScoreFileAdapter(spec.score_path)
    raise ValueError(f"Unsupported adapter method: {spec.method}")

"""End-to-end graph construction and evaluation pipelines for CAGC."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from .algorithm import CAGCConfig, CAGCCorrector
from .adapters import AdapterSpec, build_adapter
from .gating import GatedCAGCCorrector
from .graph import ConfusionAdjacencyGraph, GraphConfig
from .metrics import paired_bootstrap_improvement, top1_accuracy
from .topology import analyze_topology, topology_confidence


def build_graph_from_scores(
    validation_scores: np.ndarray,
    validation_targets: np.ndarray,
    labels: list[str] | None = None,
    graph_config: GraphConfig | None = None,
) -> ConfusionAdjacencyGraph:
    scores = np.asarray(validation_scores, dtype=np.float64)
    predictions = scores.argmax(axis=1)
    return ConfusionAdjacencyGraph.from_predictions(
        predictions=predictions,
        targets=np.asarray(validation_targets, dtype=np.int64),
        num_classes=scores.shape[1],
        config=graph_config,
        labels=labels,
    )


def evaluate_scores(
    scores: np.ndarray,
    targets: np.ndarray,
    graph: ConfusionAdjacencyGraph,
    cagc_config: CAGCConfig | None = None,
    adapter_spec: AdapterSpec | None = None,
    enable_gating: bool = False,
    gate_strength: float = 0.3,
    gate_threshold: float = 0.1,
    bootstrap_iterations: int = 10000,
    seed: int = 0,
) -> dict[str, object]:
    score_array = np.asarray(scores, dtype=np.float64)
    target_array = np.asarray(targets, dtype=np.int64)
    adapter = build_adapter(adapter_spec) if adapter_spec is not None else None
    adapted_scores = adapter.adapt_scores(score_array) if adapter is not None else score_array
    baseline_predictions = adapted_scores.argmax(axis=1)
    config = cagc_config or CAGCConfig()
    if enable_gating:
        confidence = topology_confidence(graph, gate_strength)
        corrector = GatedCAGCCorrector(graph.out_neighbors, confidence, gate_threshold, config)
    else:
        corrector = CAGCCorrector(graph.out_neighbors, config)
    corrected_predictions = corrector.correct(adapted_scores)
    improvement, bootstrap_p = paired_bootstrap_improvement(
        baseline_predictions,
        corrected_predictions,
        target_array,
        iterations=bootstrap_iterations,
        seed=seed,
    )
    return {
        "baseline_accuracy": top1_accuracy(baseline_predictions, target_array),
        "cagc_accuracy": top1_accuracy(corrected_predictions, target_array),
        "improvement": improvement,
        "bootstrap_p_value": bootstrap_p,
        "num_samples": int(target_array.size),
        "num_classes": graph.num_classes,
    }


def save_topology_report(graph: ConfusionAdjacencyGraph, path: str | Path) -> dict[str, object]:
    report = analyze_topology(graph)
    payload = report.as_dict(graph)
    import json

    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return payload

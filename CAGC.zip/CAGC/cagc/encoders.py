"""Frozen visual encoder wrappers for CLIP and DINOv2 feature extraction."""

from __future__ import annotations

from pathlib import Path

import torch
from torch import nn
import torch.nn.functional as F


class FrozenCLIPEncoder(nn.Module):
    def __init__(
        self,
        model_name: str = "ViT-B-16",
        checkpoint_path: str | Path | None = None,
        device: str = "cuda",
    ) -> None:
        super().__init__()
        try:
            import open_clip
        except ImportError as exc:
            raise ImportError("open_clip_torch is required for CLIP encoders.") from exc
        self.model_name = model_name
        self.model, _, _ = open_clip.create_model_and_transforms(
            model_name,
            pretrained=None,
            device=device,
        )
        if checkpoint_path is None:
            raise ValueError("A CLIP checkpoint path is required.")
        state = torch.load(checkpoint_path, map_location="cpu")
        if isinstance(state, dict) and "state_dict" in state:
            state = state["state_dict"]
        self.model.load_state_dict(state, strict=False)
        self.model.eval()
        for parameter in self.model.parameters():
            parameter.requires_grad_(False)
        self.device = torch.device(device)

    @torch.no_grad()
    def forward(self, images: torch.Tensor) -> torch.Tensor:
        return F.normalize(self.model.encode_image(images.to(self.device)), dim=-1)

    @torch.no_grad()
    def encode_texts(self, texts: list[str]) -> torch.Tensor:
        try:
            import open_clip
        except ImportError as exc:
            raise ImportError("open_clip_torch is required for CLIP text encoding.") from exc
        tokenizer = open_clip.get_tokenizer(self.model_name)
        tokens = tokenizer(texts).to(self.device)
        return F.normalize(self.model.encode_text(tokens), dim=-1)


class FrozenDINOv2Encoder(nn.Module):
    def __init__(
        self,
        model_name: str = "dinov2_vitb14",
        checkpoint_path: str | Path | None = None,
        device: str = "cuda",
    ) -> None:
        super().__init__()
        self.model = torch.hub.load("facebookresearch/dinov2", model_name, pretrained=False)
        if checkpoint_path is None:
            raise ValueError("A DINOv2 checkpoint path is required.")
        state = torch.load(checkpoint_path, map_location="cpu")
        if isinstance(state, dict) and "state_dict" in state:
            state = state["state_dict"]
        self.model.load_state_dict(state, strict=False)
        self.model.to(device)
        self.model.eval()
        for parameter in self.model.parameters():
            parameter.requires_grad_(False)
        self.device = torch.device(device)

    @torch.no_grad()
    def forward(self, images: torch.Tensor) -> torch.Tensor:
        return F.normalize(self.model(images.to(self.device)), dim=-1)


def build_encoder(name: str, checkpoint_path: str | Path | None, device: str = "cuda") -> nn.Module:
    normalized = name.lower()
    if "clip" in normalized:
        model_name = name if name.startswith("ViT") else "ViT-B-16"
        return FrozenCLIPEncoder(model_name=model_name, checkpoint_path=checkpoint_path, device=device)
    if "dino" in normalized:
        model_name = name if name.startswith("dinov2_") else "dinov2_vitb14"
        return FrozenDINOv2Encoder(model_name=model_name, checkpoint_path=checkpoint_path, device=device)
    raise ValueError(f"Unsupported encoder: {name}")

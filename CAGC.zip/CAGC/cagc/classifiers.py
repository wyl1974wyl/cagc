"""Unified score providers for the three center-based classifier families."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F


def softmax(logits: np.ndarray, temperature: float = 1.0) -> np.ndarray:
    scaled = np.asarray(logits, dtype=np.float64) / temperature
    scaled = scaled - scaled.max(axis=-1, keepdims=True)
    exp = np.exp(scaled)
    return exp / exp.sum(axis=-1, keepdims=True)


def cosine_scores(features: np.ndarray, class_representations: np.ndarray, temperature: float) -> np.ndarray:
    feature_tensor = torch.as_tensor(features, dtype=torch.float32)
    class_tensor = torch.as_tensor(class_representations, dtype=torch.float32)
    logits = F.normalize(feature_tensor, dim=-1) @ F.normalize(class_tensor, dim=-1).transpose(0, 1)
    return softmax(logits.numpy(), temperature=temperature)


class ZeroShotTextClassifier:
    def __init__(self, text_embeddings: np.ndarray, temperature: float = 0.01) -> None:
        self.text_embeddings = np.asarray(text_embeddings, dtype=np.float32)
        self.temperature = temperature

    def predict_scores(self, image_features: np.ndarray) -> np.ndarray:
        return cosine_scores(image_features, self.text_embeddings, self.temperature)


class LinearProbe(nn.Module):
    def __init__(self, input_dim: int, num_classes: int) -> None:
        super().__init__()
        self.linear = nn.Linear(input_dim, num_classes)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return self.linear(features)

    @torch.no_grad()
    def predict_scores(self, features: np.ndarray, device: str = "cpu") -> np.ndarray:
        tensor = torch.as_tensor(features, dtype=torch.float32, device=device)
        return F.softmax(self.forward(tensor), dim=-1).cpu().numpy()


class PrototypeClassifier:
    def __init__(self, prototypes: np.ndarray, temperature: float = 0.01) -> None:
        self.prototypes = np.asarray(prototypes, dtype=np.float32)
        self.temperature = temperature

    @classmethod
    def from_support(
        cls,
        support_features: np.ndarray,
        support_targets: np.ndarray,
        num_classes: int | None = None,
        temperature: float = 0.01,
    ) -> "PrototypeClassifier":
        features = np.asarray(support_features, dtype=np.float32)
        targets = np.asarray(support_targets, dtype=np.int64)
        class_count = num_classes or int(targets.max() + 1)
        prototypes = np.zeros((class_count, features.shape[1]), dtype=np.float32)
        for target in range(class_count):
            selected = features[targets == target]
            if selected.size:
                prototypes[target] = selected.mean(axis=0)
        return cls(prototypes, temperature=temperature)

    def predict_scores(self, features: np.ndarray) -> np.ndarray:
        return cosine_scores(features, self.prototypes, self.temperature)


class KNNClassifier:
    def __init__(self, support_features: np.ndarray, support_targets: np.ndarray, k: int = 5, temperature: float = 0.01) -> None:
        self.support_features = torch.as_tensor(support_features, dtype=torch.float32)
        self.support_targets = torch.as_tensor(support_targets, dtype=torch.long)
        self.k = k
        self.temperature = temperature

    def predict_scores(self, features: np.ndarray, num_classes: int | None = None) -> np.ndarray:
        query = F.normalize(torch.as_tensor(features, dtype=torch.float32), dim=-1)
        support = F.normalize(self.support_features, dim=-1)
        similarity = query @ support.transpose(0, 1)
        k = min(self.k, similarity.shape[1])
        _, indices = similarity.topk(k, dim=1)
        class_count = num_classes or int(self.support_targets.max().item() + 1)
        votes = torch.zeros((query.shape[0], class_count), dtype=torch.float32)
        neighbor_targets = self.support_targets[indices]
        votes.scatter_add_(1, neighbor_targets, torch.ones_like(neighbor_targets, dtype=torch.float32))
        return softmax(votes.numpy(), temperature=self.temperature)


@dataclass(frozen=True)
class ClassifierSpec:
    family: str
    temperature: float = 0.01


def build_classifier(
    family: str,
    image_features: np.ndarray | None = None,
    text_embeddings: np.ndarray | None = None,
    probe: LinearProbe | None = None,
    support_features: np.ndarray | None = None,
    support_targets: np.ndarray | None = None,
    temperature: float = 0.01,
) -> object:
    normalized = family.lower().replace("-", "_")
    if normalized in {"family_i", "zero_shot", "text_aligned"}:
        if text_embeddings is None:
            raise ValueError("Text embeddings are required for Family I.")
        return ZeroShotTextClassifier(text_embeddings, temperature=temperature)
    if normalized in {"family_ii", "linear_probe"}:
        if probe is None:
            raise ValueError("A linear probe is required for Family II.")
        return probe
    if normalized in {"family_iii", "prototype"}:
        if support_features is None or support_targets is None:
            raise ValueError("Support features and targets are required for Family III.")
        return PrototypeClassifier.from_support(support_features, support_targets, temperature=temperature)
    raise ValueError(f"Unsupported classifier family: {family}")

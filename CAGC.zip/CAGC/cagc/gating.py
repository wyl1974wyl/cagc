"""Optional topology-aware gating for classes with diffuse confusion structure."""

from __future__ import annotations

from typing import Mapping, Sequence

import numpy as np

from .algorithm import CAGCConfig


class GatedCAGCCorrector:
    def __init__(
        self,
        out_neighbors: Mapping[int, Sequence[int]],
        topology_confidence: np.ndarray,
        gate_threshold: float,
        config: CAGCConfig | None = None,
    ) -> None:
        self.out_neighbors = {int(k): {int(v) for v in values} for k, values in out_neighbors.items()}
        self.topology_confidence = np.asarray(topology_confidence, dtype=np.float64)
        self.gate_threshold = float(gate_threshold)
        self.config = config or CAGCConfig()

    def correct_one(self, scores: np.ndarray | Sequence[float]) -> int:
        score_array = np.asarray(scores, dtype=np.float64)
        ranking = np.argsort(-score_array, kind="stable")
        step = 0
        current = int(ranking[0])
        if score_array[current] > self.config.gamma:
            return current
        while step < self.config.max_steps and step + 1 < ranking.size:
            runner_up = int(ranking[step + 1])
            margin = score_array[current] - score_array[runner_up]
            if margin > self.config.tau or runner_up in self.out_neighbors.get(current, set()):
                break
            if self.topology_confidence[current] < self.gate_threshold:
                break
            current = runner_up
            step += 1
        return current

    def correct(self, scores: np.ndarray) -> np.ndarray:
        score_array = np.asarray(scores, dtype=np.float64)
        if score_array.ndim == 1:
            return np.asarray(self.correct_one(score_array), dtype=np.int64)
        return np.asarray([self.correct_one(row) for row in score_array], dtype=np.int64)

"""Checkpoint loading utilities with paper-release placeholders."""

from __future__ import annotations

from pathlib import Path

import torch


def load_state_dict(path: str | Path | None, map_location: str = "cpu") -> dict[str, torch.Tensor]:
    if path is None:
        raise ValueError(
            "Checkpoint path is empty. Trained weights will be released after the paper is accepted."
        )
    checkpoint = torch.load(path, map_location=map_location)
    if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
        return checkpoint["state_dict"]
    if isinstance(checkpoint, dict) and "model" in checkpoint:
        return checkpoint["model"]
    if not isinstance(checkpoint, dict):
        raise TypeError("The checkpoint does not contain a state dictionary.")
    return checkpoint


def save_state_dict(model: torch.nn.Module, path: str | Path, metadata: dict[str, object] | None = None) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"state_dict": model.state_dict(), "metadata": metadata or {}}, output)

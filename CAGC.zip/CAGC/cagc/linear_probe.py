"""Linear probe training on frozen visual features."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm

from .classifiers import LinearProbe


@dataclass(frozen=True)
class LinearProbeConfig:
    epochs: int = 100
    batch_size: int = 1024
    lr: float = 0.1
    momentum: float = 0.9
    weight_decay: float = 0.0
    label_smoothing: float = 0.0


def train_linear_probe(
    train_features: np.ndarray,
    train_targets: np.ndarray,
    num_classes: int,
    config: LinearProbeConfig | None = None,
    device: str = "cuda",
    seed: int = 0,
) -> LinearProbe:
    config = config or LinearProbeConfig()
    torch.manual_seed(seed)
    dataset = TensorDataset(
        torch.as_tensor(train_features, dtype=torch.float32),
        torch.as_tensor(train_targets, dtype=torch.long),
    )
    generator = torch.Generator()
    generator.manual_seed(seed)
    loader = DataLoader(dataset, batch_size=config.batch_size, shuffle=True, generator=generator)
    model = LinearProbe(train_features.shape[1], num_classes).to(device)
    criterion = nn.CrossEntropyLoss(label_smoothing=config.label_smoothing)
    optimizer = torch.optim.SGD(
        model.parameters(),
        lr=config.lr,
        momentum=config.momentum,
        weight_decay=config.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=config.epochs)
    model.train()
    for _ in tqdm(range(config.epochs), desc="Training linear probe"):
        for features, targets in loader:
            features = features.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)
            loss = criterion(model(features), targets)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
        scheduler.step()
    model.eval()
    return model

"""Confusion Adjacency Graph Correction inference algorithm."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np


@dataclass(frozen=True)
class CAGCConfig:
    gamma: float = 0.6
    tau: float = 0.15
    max_steps: int = 3


class CAGCCorrector:
    def __init__(
        self,
        out_neighbors: Mapping[int, Sequence[int]] | np.ndarray,
        config: CAGCConfig | None = None,
    ) -> None:
        self.config = config or CAGCConfig()
        self.out_neighbors = self._normalize_neighbors(out_neighbors)

    @staticmethod
    def _normalize_neighbors(
        out_neighbors: Mapping[int, Sequence[int]] | np.ndarray,
    ) -> dict[int, set[int]]:
        if isinstance(out_neighbors, np.ndarray):
            if out_neighbors.ndim != 2 or out_neighbors.shape[0] != out_neighbors.shape[1]:
                raise ValueError("A neighbor matrix must be square.")
            return {
                source: set(np.flatnonzero(out_neighbors[source]).tolist())
                for source in range(out_neighbors.shape[0])
            }
        return {int(source): {int(target) for target in targets} for source, targets in out_neighbors.items()}

    def correct_one(self, scores: np.ndarray | Sequence[float]) -> int:
        score_array = np.asarray(scores, dtype=np.float64)
        if score_array.ndim != 1 or score_array.size == 0:
            raise ValueError("Scores must be a non-empty one-dimensional vector.")
        ranking = np.argsort(-score_array, kind="stable")
        step = 0
        current = int(ranking[0])
        if score_array[current] > self.config.gamma:
            return current
        while step < self.config.max_steps and step + 1 < ranking.size:
            runner_up = int(ranking[step + 1])
            margin = score_array[current] - score_array[runner_up]
            if margin > self.config.tau or runner_up in self.out_neighbors.get(current, set()):
                break
            current = runner_up
            step += 1
        return current

    def correct(self, scores: np.ndarray) -> np.ndarray:
        score_array = np.asarray(scores, dtype=np.float64)
        if score_array.ndim == 1:
            return np.asarray(self.correct_one(score_array), dtype=np.int64)
        if score_array.ndim != 2:
            raise ValueError("Scores must have shape [num_classes] or [num_samples, num_classes].")
        return np.asarray([self.correct_one(row) for row in score_array], dtype=np.int64)

    def trace_one(self, scores: np.ndarray | Sequence[float]) -> dict[str, object]:
        score_array = np.asarray(scores, dtype=np.float64)
        ranking = np.argsort(-score_array, kind="stable")
        step = 0
        current = int(ranking[0])
        decisions: list[dict[str, object]] = []
        if score_array[current] > self.config.gamma:
            return {
                "prediction": current,
                "ranking": ranking.tolist(),
                "steps": step,
                "accepted_by": "confidence",
                "decisions": decisions,
            }
        while step < self.config.max_steps and step + 1 < ranking.size:
            runner_up = int(ranking[step + 1])
            margin = float(score_array[current] - score_array[runner_up])
            historical = runner_up in self.out_neighbors.get(current, set())
            decisions.append(
                {
                    "step": step + 1,
                    "current": current,
                    "runner_up": runner_up,
                    "margin": margin,
                    "historical_neighbor": historical,
                }
            )
            if margin > self.config.tau or historical:
                return {
                    "prediction": current,
                    "ranking": ranking.tolist(),
                    "steps": step,
                    "accepted_by": "margin" if margin > self.config.tau else "history",
                    "decisions": decisions,
                }
            current = runner_up
            step += 1
        return {
            "prediction": current,
            "ranking": ranking.tolist(),
            "steps": step,
            "accepted_by": "step_limit",
            "decisions": decisions,
        }

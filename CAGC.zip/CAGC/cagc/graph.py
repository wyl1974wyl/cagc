"""Directed confusion graph construction, serialization, and sampling."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

import numpy as np


@dataclass(frozen=True)
class GraphConfig:
    edge_threshold: float = 0.05
    top_k: int = 5


class ConfusionAdjacencyGraph:
    def __init__(
        self,
        weights: np.ndarray,
        out_neighbors: Mapping[int, list[int]],
        labels: list[str] | None = None,
    ) -> None:
        self.weights = np.asarray(weights, dtype=np.float64)
        if self.weights.ndim != 2 or self.weights.shape[0] != self.weights.shape[1]:
            raise ValueError("Graph weights must be a square matrix.")
        self.out_neighbors = {int(k): [int(v) for v in values] for k, values in out_neighbors.items()}
        self.labels = labels or [str(index) for index in range(self.weights.shape[0])]

    @property
    def num_classes(self) -> int:
        return int(self.weights.shape[0])

    @classmethod
    def from_predictions(
        cls,
        predictions: np.ndarray,
        targets: np.ndarray,
        num_classes: int | None = None,
        config: GraphConfig | None = None,
        labels: list[str] | None = None,
    ) -> "ConfusionAdjacencyGraph":
        config = config or GraphConfig()
        predictions = np.asarray(predictions, dtype=np.int64)
        targets = np.asarray(targets, dtype=np.int64)
        if predictions.shape != targets.shape:
            raise ValueError("Predictions and targets must have identical shapes.")
        inferred = int(max(predictions.max(initial=-1), targets.max(initial=-1)) + 1)
        class_count = num_classes or inferred
        matrix = np.zeros((class_count, class_count), dtype=np.float64)
        valid = (targets >= 0) & (targets < class_count) & (predictions >= 0) & (predictions < class_count)
        np.add.at(matrix, (targets[valid], predictions[valid]), 1.0)
        return cls.from_confusion_matrix(matrix, config=config, labels=labels)

    @classmethod
    def from_confusion_matrix(
        cls,
        matrix: np.ndarray,
        config: GraphConfig | None = None,
        labels: list[str] | None = None,
    ) -> "ConfusionAdjacencyGraph":
        config = config or GraphConfig()
        matrix = np.asarray(matrix, dtype=np.float64)
        if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
            raise ValueError("The confusion matrix must be square.")
        weights = np.zeros_like(matrix, dtype=np.float64)
        neighbors: dict[int, list[int]] = {}
        for source in range(matrix.shape[0]):
            off_diagonal = matrix[source].copy()
            off_diagonal[source] = 0.0
            denominator = float(off_diagonal.sum())
            if denominator > 0.0:
                weights[source] = off_diagonal / denominator
            candidates = [
                int(target)
                for target in range(matrix.shape[1])
                if target != source and weights[source, target] > config.edge_threshold
            ]
            candidates.sort(key=lambda target: (-weights[source, target], target))
            neighbors[source] = candidates[: config.top_k]
        return cls(weights=weights, out_neighbors=neighbors, labels=labels)

    def adjacency_matrix(self) -> np.ndarray:
        adjacency = np.zeros_like(self.weights, dtype=bool)
        for source, targets in self.out_neighbors.items():
            if targets:
                adjacency[source, np.asarray(targets, dtype=np.int64)] = True
        return adjacency

    def edge_overlap(self, other: "ConfusionAdjacencyGraph") -> float:
        if self.num_classes != other.num_classes:
            raise ValueError("Graphs must have the same number of classes.")
        own = self.adjacency_matrix()
        theirs = other.adjacency_matrix()
        denominator = int(np.logical_or(own, theirs).sum())
        if denominator == 0:
            return 1.0
        return float(np.logical_and(own, theirs).sum() / denominator)

    def random_neighbor_graph(self, seed: int, top_k: int | None = None) -> "ConfusionAdjacencyGraph":
        rng = np.random.default_rng(seed)
        neighbor_count = top_k if top_k is not None else max(len(v) for v in self.out_neighbors.values())
        random_neighbors: dict[int, list[int]] = {}
        for source in range(self.num_classes):
            candidates = np.delete(np.arange(self.num_classes), source)
            random_neighbors[source] = rng.choice(
                candidates,
                size=min(neighbor_count, candidates.size),
                replace=False,
            ).astype(int).tolist()
        return ConfusionAdjacencyGraph(self.weights.copy(), random_neighbors, self.labels.copy())

    def save(self, path: str | Path) -> None:
        output = Path(path)
        output.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "num_classes": self.num_classes,
            "labels": self.labels,
            "out_neighbors": {str(k): v for k, v in self.out_neighbors.items()},
            "weights": self.weights.tolist(),
        }
        output.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "ConfusionAdjacencyGraph":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(
            weights=np.asarray(payload["weights"], dtype=np.float64),
            out_neighbors={int(k): [int(v) for v in values] for k, values in payload["out_neighbors"].items()},
            labels=[str(label) for label in payload.get("labels", [])] or None,
        )

    def save_npz(self, path: str | Path) -> None:
        output = Path(path)
        output.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            output,
            weights=self.weights,
            adjacency=self.adjacency_matrix(),
            labels=np.asarray(self.labels, dtype=object),
        )

"""Batch feature extraction, caching, and few-shot episode sampling."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm


@torch.no_grad()
def extract_features(
    model: torch.nn.Module,
    dataset: Dataset,
    batch_size: int = 256,
    num_workers: int = 8,
    device: str = "cuda",
) -> tuple[np.ndarray, np.ndarray]:
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )
    features: list[np.ndarray] = []
    targets: list[np.ndarray] = []
    for images, labels in tqdm(loader, desc="Extracting features"):
        batch_features = model(images.to(device, non_blocking=True))
        features.append(batch_features.detach().cpu().numpy())
        targets.append(labels.numpy())
    return np.concatenate(features, axis=0), np.concatenate(targets, axis=0)


def save_features(path: str | Path, features: np.ndarray, targets: np.ndarray) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output, features=features.astype(np.float32), targets=targets.astype(np.int64))


def load_features(path: str | Path) -> tuple[np.ndarray, np.ndarray]:
    payload = np.load(path, allow_pickle=False)
    return payload["features"].astype(np.float32), payload["targets"].astype(np.int64)


def sample_support_episode(
    features: np.ndarray,
    targets: np.ndarray,
    shots: int,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    support_features: list[np.ndarray] = []
    support_targets: list[int] = []
    for target in np.unique(targets):
        candidates = np.flatnonzero(targets == target)
        if candidates.size == 0:
            continue
        selected = rng.choice(candidates, size=min(shots, candidates.size), replace=False)
        support_features.append(features[selected])
        support_targets.extend([int(target)] * len(selected))
    if not support_features:
        raise ValueError("The episode contains no support samples.")
    return np.concatenate(support_features, axis=0), np.asarray(support_targets, dtype=np.int64)

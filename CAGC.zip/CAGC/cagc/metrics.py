"""Evaluation metrics and significance tests used by the CAGC experiments."""

from __future__ import annotations

import numpy as np


def top1_accuracy(predictions: np.ndarray, targets: np.ndarray) -> float:
    predictions = np.asarray(predictions)
    targets = np.asarray(targets)
    if predictions.shape != targets.shape:
        raise ValueError("Predictions and targets must have identical shapes.")
    return float((predictions == targets).mean() * 100.0)


def accuracy_with_std(predictions_by_episode: list[np.ndarray], targets: np.ndarray) -> tuple[float, float]:
    values = np.asarray([top1_accuracy(predictions, targets) for predictions in predictions_by_episode], dtype=np.float64)
    return float(values.mean()), float(values.std(ddof=1)) if len(values) > 1 else 0.0


def paired_bootstrap_improvement(
    baseline: np.ndarray,
    corrected: np.ndarray,
    targets: np.ndarray,
    iterations: int = 10000,
    seed: int = 0,
) -> tuple[float, float]:
    baseline_correct = np.asarray(baseline) == np.asarray(targets)
    corrected_correct = np.asarray(corrected) == np.asarray(targets)
    differences = corrected_correct.astype(np.float64) - baseline_correct.astype(np.float64)
    rng = np.random.default_rng(seed)
    estimates = np.empty(iterations, dtype=np.float64)
    for index in range(iterations):
        sample = rng.choice(differences, size=differences.size, replace=True)
        estimates[index] = sample.mean()
    return float(differences.mean() * 100.0), float(np.mean(estimates <= 0.0))


def paired_t_test(baseline_scores: list[float], corrected_scores: list[float]) -> tuple[float, float]:
    from scipy.stats import ttest_rel

    result = ttest_rel(corrected_scores, baseline_scores)
    return float(result.statistic), float(result.pvalue)


def confusion_matrix(predictions: np.ndarray, targets: np.ndarray, num_classes: int) -> np.ndarray:
    matrix = np.zeros((num_classes, num_classes), dtype=np.int64)
    np.add.at(matrix, (np.asarray(targets, dtype=np.int64), np.asarray(predictions, dtype=np.int64)), 1)
    return matrix


def correction_behavior(
    baseline: np.ndarray,
    corrected: np.ndarray,
    targets: np.ndarray,
    topology: list[str],
) -> dict[str, dict[str, float | int]]:
    report: dict[str, dict[str, float | int]] = {}
    changed = np.asarray(corrected) != np.asarray(baseline)
    for group in sorted(set(topology)):
        class_ids = [index for index, name in enumerate(topology) if name == group]
        mask = changed & np.isin(np.asarray(baseline), class_ids)
        fixed = mask & (np.asarray(corrected) == np.asarray(targets))
        broken = mask & (np.asarray(corrected) != np.asarray(targets))
        corrected_count = int(fixed.sum())
        miscorrected_count = int(broken.sum())
        total = corrected_count + miscorrected_count
        report[group] = {
            "classes": len(class_ids),
            "corrected": corrected_count,
            "miscorrected": miscorrected_count,
            "precision": corrected_count / total if total else 0.0,
        }
    return report

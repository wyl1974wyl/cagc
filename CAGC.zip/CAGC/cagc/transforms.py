"""Image preprocessing transforms for supported frozen visual encoders."""

from __future__ import annotations

from torchvision import transforms


def clip_transform(image_size: int = 224):
    return transforms.Compose(
        [
            transforms.Resize(image_size, interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=(0.48145466, 0.4578275, 0.40821073),
                std=(0.26862954, 0.26130258, 0.27577711),
            ),
        ]
    )


def dinov2_transform(image_size: int = 224):
    return transforms.Compose(
        [
            transforms.Resize(image_size, interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
        ]
    )


def build_transform(encoder_name: str, image_size: int = 224):
    normalized = encoder_name.lower()
    if "clip" in normalized:
        return clip_transform(image_size)
    if "dino" in normalized:
        return dinov2_transform(image_size)
    raise ValueError(f"No transform is registered for encoder {encoder_name}.")

"""Public API for Confusion Adjacency Graph Correction."""

from .algorithm import CAGCConfig, CAGCCorrector
from .classifiers import LinearProbe, PrototypeClassifier, ZeroShotTextClassifier
from .gating import GatedCAGCCorrector
from .graph import ConfusionAdjacencyGraph, GraphConfig
from .metrics import top1_accuracy
from .topology import TopologyConfig, analyze_topology, topology_confidence

__all__ = [
    "CAGCConfig",
    "CAGCCorrector",
    "ConfusionAdjacencyGraph",
    "GatedCAGCCorrector",
    "GraphConfig",
    "LinearProbe",
    "PrototypeClassifier",
    "TopologyConfig",
    "ZeroShotTextClassifier",
    "analyze_topology",
    "top1_accuracy",
    "topology_confidence",
]

"""Dataset adapters for ImageNet, ImageNet-C, and manifest-based fine-grained benchmarks."""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from PIL import Image
from torch.utils.data import Dataset
from torchvision.datasets import ImageFolder


@dataclass(frozen=True)
class DatasetSpec:
    name: str
    root: str
    split: str = "test"
    manifest: str | None = None
    corruption: str | None = None
    severity: int | None = None


class ManifestImageDataset(Dataset):
    def __init__(
        self,
        root: str | Path,
        manifest: str | Path,
        transform: Callable | None = None,
        label_offset: int = 0,
    ) -> None:
        self.root = Path(root)
        self.manifest = Path(manifest)
        self.transform = transform
        self.label_offset = label_offset
        self.samples: list[tuple[Path, int]] = []
        with self.manifest.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                self.samples.append((self.root / row["path"], int(row["label"]) + label_offset))
        if not self.samples:
            raise ValueError(f"No samples were loaded from {self.manifest}.")

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int):
        path, target = self.samples[index]
        image = Image.open(path).convert("RGB")
        if self.transform is not None:
            image = self.transform(image)
        return image, target

    @property
    def targets(self) -> list[int]:
        return [target for _, target in self.samples]


class ImageNetCDataset(ManifestImageDataset):
    def __init__(
        self,
        root: str | Path,
        corruption: str,
        severity: int,
        transform: Callable | None = None,
    ) -> None:
        corruption_root = Path(root) / corruption / str(severity)
        manifest = corruption_root / "manifest.csv"
        if not manifest.exists():
            raise FileNotFoundError(
                f"Expected an ImageNet-C manifest at {manifest} with columns path,label."
            )
        super().__init__(corruption_root, manifest, transform=transform)


def build_dataset(spec: DatasetSpec, transform: Callable | None = None) -> Dataset:
    name = spec.name.lower()
    root = Path(spec.root)
    if name in {"imagenet", "imagenet1k", "imagenet-1k"}:
        split_root = root / spec.split
        if not split_root.exists():
            split_root = root
        return ImageFolder(split_root, transform=transform)
    if name in {"imagenet-c", "imagenet_c", "inc"}:
        if spec.corruption is None or spec.severity is None:
            raise ValueError("ImageNet-C requires a corruption and severity.")
        return ImageNetCDataset(root, spec.corruption, spec.severity, transform=transform)
    if spec.manifest is None:
        raise ValueError("Fine-grained datasets require a CSV manifest with path,label columns.")
    return ManifestImageDataset(root, spec.manifest, transform=transform)


def class_names(dataset: Dataset) -> list[str]:
    if hasattr(dataset, "classes"):
        return [str(item) for item in dataset.classes]
    if hasattr(dataset, "targets"):
        count = max(dataset.targets) + 1
        return [str(index) for index in range(count)]
    raise ValueError("Class names are unavailable for this dataset.")


IMAGENET_C_CORRUPTIONS = [
    "gaussian_noise",
    "shot_noise",
    "impulse_noise",
    "defocus_blur",
    "glass_blur",
    "motion_blur",
    "zoom_blur",
    "snow",
    "frost",
    "fog",
    "brightness",
    "contrast",
    "elastic_transform",
    "pixelate",
    "jpeg_compression",
]

CORRUPTION_GROUPS = {
    "noise": ["gaussian_noise", "shot_noise", "impulse_noise"],
    "blur": ["defocus_blur", "glass_blur", "motion_blur", "zoom_blur"],
    "weather": ["snow", "frost", "fog", "brightness"],
    "digital": ["contrast", "elastic_transform", "pixelate", "jpeg_compression"],
}

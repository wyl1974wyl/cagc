"""Command-line feature extraction for a dataset and frozen encoder."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cagc.datasets import DatasetSpec, build_dataset
from cagc.encoders import build_encoder
from cagc.features import extract_features, save_features
from cagc.transforms import build_transform
from cagc.utils import load_config, resolve_device, set_seed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--dataset", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    dataset_config = config["datasets"][args.dataset]
    set_seed(int(config.get("seed", 0)))
    device = resolve_device(config.get("device", "auto"))
    encoder_config = config["encoder"]
    encoder = build_encoder(
        encoder_config["name"],
        encoder_config.get("checkpoint_path"),
        device=device,
    )
    transform = build_transform(encoder_config["name"], int(encoder_config.get("image_size", 224)))
    dataset = build_dataset(
        DatasetSpec(
            name=dataset_config["name"],
            root=dataset_config["root"],
            split=dataset_config.get("split", "test"),
            manifest=dataset_config.get("manifest"),
            corruption=dataset_config.get("corruption"),
            severity=dataset_config.get("severity"),
        ),
        transform=transform,
    )
    features, targets = extract_features(
        encoder,
        dataset,
        batch_size=int(config.get("batch_size", 256)),
        num_workers=int(config.get("num_workers", 8)),
        device=device,
    )
    save_features(dataset_config["features_path"], features, targets)


if __name__ == "__main__":
    main()

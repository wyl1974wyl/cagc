"""Command-line training for Family II linear probes."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cagc.checkpointing import save_state_dict
from cagc.features import load_features
from cagc.linear_probe import LinearProbeConfig, train_linear_probe
from cagc.utils import load_config, resolve_device, set_seed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--train-features", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    probe_config = config.get("linear_probe", {})
    set_seed(int(config.get("seed", 0)))
    features, targets = load_features(args.train_features)
    model = train_linear_probe(
        features,
        targets,
        num_classes=int(config["num_classes"]),
        config=LinearProbeConfig(**probe_config),
        device=resolve_device(config.get("device", "auto")),
        seed=int(config.get("seed", 0)),
    )
    save_state_dict(model, args.output, metadata={"family": "II", "input_dim": int(features.shape[1])})


if __name__ == "__main__":
    main()

"""Command-line score prediction for the three classifier families."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from cagc.checkpointing import load_state_dict
from cagc.classifiers import LinearProbe, PrototypeClassifier, ZeroShotTextClassifier
from cagc.features import load_features
from cagc.utils import load_config, resolve_device


def save_scores(path: str, scores: np.ndarray) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output, scores=scores.astype(np.float64))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--family", choices=["I", "II", "III"], required=True)
    parser.add_argument("--features", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--text-embeddings", default=None)
    parser.add_argument("--probe-checkpoint", default=None)
    parser.add_argument("--support-features", default=None)
    args = parser.parse_args()
    config = load_config(args.config)
    features, _ = load_features(args.features)
    temperature = float(config.get("temperature", 0.01))
    if args.family == "I":
        if args.text_embeddings is None:
            raise ValueError("Family I requires --text-embeddings.")
        text_embeddings = np.load(args.text_embeddings)
        classifier = ZeroShotTextClassifier(text_embeddings, temperature=temperature)
        scores = classifier.predict_scores(features)
    elif args.family == "II":
        if args.probe_checkpoint is None:
            raise ValueError("Family II requires --probe-checkpoint.")
        probe = LinearProbe(int(features.shape[1]), int(config["num_classes"]))
        probe.load_state_dict(load_state_dict(args.probe_checkpoint))
        probe.to(resolve_device(config.get("device", "auto")))
        scores = probe.predict_scores(features, device=resolve_device(config.get("device", "auto")))
    else:
        if args.support_features is None:
            raise ValueError("Family III requires --support-features.")
        support_features, support_targets = load_features(args.support_features)
        classifier = PrototypeClassifier.from_support(
            support_features,
            support_targets,
            num_classes=int(config["num_classes"]),
            temperature=temperature,
        )
        scores = classifier.predict_scores(features)
    save_scores(args.output, scores)


if __name__ == "__main__":
    main()

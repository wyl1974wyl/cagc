"""Topology-conditioned correction behavior analysis."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from cagc.algorithm import CAGCConfig, CAGCCorrector
from cagc.graph import ConfusionAdjacencyGraph
from cagc.metrics import correction_behavior
from cagc.topology import analyze_topology
from cagc.utils import load_config, save_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--scores", required=True)
    parser.add_argument("--targets", required=True)
    parser.add_argument("--graph", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    scores = np.load(args.scores)["scores"] if args.scores.endswith(".npz") else np.load(args.scores)
    targets = np.load(args.targets)["targets"] if args.targets.endswith(".npz") else np.load(args.targets)
    graph = ConfusionAdjacencyGraph.load(args.graph)
    baseline = scores.argmax(axis=1)
    corrected = CAGCCorrector(graph.out_neighbors, CAGCConfig(**config.get("cagc", {}))).correct(scores)
    topology = analyze_topology(graph).topology
    save_json(correction_behavior(baseline, corrected, targets, topology), args.output)


if __name__ == "__main__":
    main()

"""Command-line multi-episode Family III evaluation with CAGC."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cagc.algorithm import CAGCConfig, CAGCCorrector
from cagc.classifiers import PrototypeClassifier
from cagc.features import load_features, sample_support_episode
from cagc.graph import ConfusionAdjacencyGraph
from cagc.metrics import accuracy_with_std
from cagc.utils import load_config, save_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--support-features", required=True)
    parser.add_argument("--query-features", required=True)
    parser.add_argument("--graph", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    support_features, support_targets = load_features(args.support_features)
    query_features, query_targets = load_features(args.query_features)
    graph = ConfusionAdjacencyGraph.load(args.graph)
    corrector = CAGCCorrector(graph.out_neighbors, CAGCConfig(**config.get("cagc", {})))
    episodes = int(config.get("episodes", 5))
    shots = int(config.get("shots", 5))
    baseline_predictions = []
    corrected_predictions = []
    for episode in range(episodes):
        episode_features, episode_targets = sample_support_episode(
            support_features,
            support_targets,
            shots=shots,
            seed=int(config.get("seed", 0)) + episode,
        )
        classifier = PrototypeClassifier.from_support(
            episode_features,
            episode_targets,
            num_classes=int(config["num_classes"]),
            temperature=float(config.get("temperature", 0.01)),
        )
        scores = classifier.predict_scores(query_features)
        baseline_predictions.append(scores.argmax(axis=1))
        corrected_predictions.append(corrector.correct(scores))
    baseline_mean, baseline_std = accuracy_with_std(baseline_predictions, query_targets)
    corrected_mean, corrected_std = accuracy_with_std(corrected_predictions, query_targets)
    save_json(
        {
            "shots": shots,
            "episodes": episodes,
            "baseline_accuracy_mean": baseline_mean,
            "baseline_accuracy_std": baseline_std,
            "cagc_accuracy_mean": corrected_mean,
            "cagc_accuracy_std": corrected_std,
        },
        args.output,
    )


if __name__ == "__main__":
    main()

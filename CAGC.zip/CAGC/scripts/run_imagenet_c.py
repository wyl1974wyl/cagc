"""Batch ImageNet-C evaluation across all fifteen corruption types."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from cagc.algorithm import CAGCConfig, CAGCCorrector
from cagc.datasets import CORRUPTION_GROUPS, IMAGENET_C_CORRUPTIONS
from cagc.graph import ConfusionAdjacencyGraph
from cagc.metrics import top1_accuracy
from cagc.utils import load_config, save_json


def load_npz(path: str | Path, key: str) -> np.ndarray:
    return np.load(path)[key]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--scores-dir", required=True)
    parser.add_argument("--targets", required=True)
    parser.add_argument("--graph", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    targets = load_npz(args.targets, "targets")
    graph = ConfusionAdjacencyGraph.load(args.graph)
    corrector = CAGCCorrector(graph.out_neighbors, CAGCConfig(**config.get("cagc", {})))
    results: dict[str, dict[str, float]] = {}
    for corruption in IMAGENET_C_CORRUPTIONS:
        scores = load_npz(Path(args.scores_dir) / f"{corruption}.npz", "scores")
        baseline = scores.argmax(axis=1)
        corrected = corrector.correct(scores)
        results[corruption] = {
            "baseline": top1_accuracy(baseline, targets),
            "cagc": top1_accuracy(corrected, targets),
        }
    grouped: dict[str, dict[str, float]] = {}
    for group, names in CORRUPTION_GROUPS.items():
        grouped[group] = {
            "baseline": float(np.mean([results[name]["baseline"] for name in names])),
            "cagc": float(np.mean([results[name]["cagc"] for name in names])),
        }
    grouped["mean"] = {
        "baseline": float(np.mean([item["baseline"] for item in results.values()])),
        "cagc": float(np.mean([item["cagc"] for item in results.values()])),
    }
    save_json({"corruptions": results, "groups": grouped}, args.output)


if __name__ == "__main__":
    main()

"""Export prompt-based CLIP text embeddings for Family I classification."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from cagc.encoders import FrozenCLIPEncoder
from cagc.utils import load_config, resolve_device


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--class-names", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--template", default="a photo of a {}.")
    args = parser.parse_args()
    config = load_config(args.config)
    labels = [line.strip() for line in Path(args.class_names).read_text(encoding="utf-8").splitlines() if line.strip()]
    prompts = [args.template.format(label.replace("_", " ")) for label in labels]
    encoder_config = config["encoder"]
    encoder = FrozenCLIPEncoder(
        model_name=encoder_config.get("model_name", "ViT-B-16"),
        checkpoint_path=encoder_config.get("checkpoint_path"),
        device=resolve_device(config.get("device", "auto")),
    )
    embeddings = encoder.encode_texts(prompts).cpu().numpy()
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    np.save(output, embeddings.astype(np.float32))


if __name__ == "__main__":
    main()

"""Command-line CAGC evaluation from class-score files and a saved graph."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cagc.algorithm import CAGCConfig
from cagc.adapters import AdapterSpec
from cagc.graph import ConfusionAdjacencyGraph
from cagc.pipeline import evaluate_scores
from cagc.utils import load_config, save_json


def load_array(path: str, key: str):
    import numpy as np

    if path.endswith(".npz"):
        return np.load(path)[key]
    return np.load(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--scores", required=True)
    parser.add_argument("--targets", required=True)
    parser.add_argument("--graph", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--adapter-method", default=None)
    parser.add_argument("--adapter-scores", default=None)
    args = parser.parse_args()
    config = load_config(args.config)
    scores = load_array(args.scores, "scores")
    targets = load_array(args.targets, "targets")
    graph = ConfusionAdjacencyGraph.load(args.graph)
    adapter = None
    if args.adapter_method is not None:
        adapter = AdapterSpec(method=args.adapter_method, score_path=args.adapter_scores)
    report = evaluate_scores(
        scores,
        targets,
        graph,
        cagc_config=CAGCConfig(**config.get("cagc", {})),
        adapter_spec=adapter,
        enable_gating=bool(config.get("gating", {}).get("enabled", False)),
        gate_strength=float(config.get("gating", {}).get("strength", 0.3)),
        gate_threshold=float(config.get("gating", {}).get("threshold", 0.1)),
        bootstrap_iterations=int(config.get("bootstrap_iterations", 10000)),
        seed=int(config.get("seed", 0)),
    )
    save_json(report, args.output)


if __name__ == "__main__":
    main()

"""Graph transfer diagnostics for corruption graphs, random neighbors, and subset validation."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cagc.graph import ConfusionAdjacencyGraph
from cagc.utils import save_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--clean-graph", required=True)
    parser.add_argument("--corruption-graph", default=None)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    clean = ConfusionAdjacencyGraph.load(args.clean_graph)
    payload: dict[str, object] = {
        "clean_edges": int(clean.adjacency_matrix().sum()),
        "random_edges": int(clean.random_neighbor_graph(args.seed, args.top_k).adjacency_matrix().sum()),
    }
    if args.corruption_graph is not None:
        corruption = ConfusionAdjacencyGraph.load(args.corruption_graph)
        payload["edge_overlap"] = clean.edge_overlap(corruption)
        payload["corruption_edges"] = int(corruption.adjacency_matrix().sum())
    save_json(payload, args.output)


if __name__ == "__main__":
    main()

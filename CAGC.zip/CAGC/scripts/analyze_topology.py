"""Command-line topology analysis for a saved confusion adjacency graph."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cagc.graph import ConfusionAdjacencyGraph
from cagc.pipeline import save_topology_report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    graph = ConfusionAdjacencyGraph.load(args.graph)
    save_topology_report(graph, args.output)


if __name__ == "__main__":
    main()

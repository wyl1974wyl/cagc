"""Command-line construction of the validation confusion adjacency graph."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cagc.graph import ConfusionAdjacencyGraph, GraphConfig
from cagc.pipeline import build_graph_from_scores
from cagc.utils import load_config, save_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--scores", required=True)
    parser.add_argument("--targets", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    graph_config = GraphConfig(**config.get("graph", {}))
    import numpy as np

    scores = np.load(args.scores)["scores"] if args.scores.endswith(".npz") else np.load(args.scores)
    targets = np.load(args.targets)["targets"] if args.targets.endswith(".npz") else np.load(args.targets)
    graph = build_graph_from_scores(
        scores,
        targets,
        labels=config.get("class_names"),
        graph_config=graph_config,
    )
    graph.save(args.output)
    graph.save_npz(str(Path(args.output).with_suffix(".npz")))
    save_json({"num_classes": graph.num_classes, "output": args.output}, Path(args.output).with_suffix(".summary.json"))


if __name__ == "__main__":
    main()

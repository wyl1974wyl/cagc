"""Minimal synthetic example showing graph construction and CAGC correction."""

from __future__ import annotations

import numpy as np

from cagc import CAGCCorrector, ConfusionAdjacencyGraph


def main() -> None:
    targets = np.asarray([0, 0, 1, 1, 2, 2, 0, 1])
    predictions = np.asarray([0, 1, 1, 2, 2, 0, 1, 1])
    graph = ConfusionAdjacencyGraph.from_predictions(predictions, targets, num_classes=3)
    scores = np.asarray(
        [
            [0.40, 0.39, 0.21],
            [0.31, 0.30, 0.39],
        ]
    )
    corrector = CAGCCorrector(graph.out_neighbors)
    print(corrector.correct(scores).tolist())
    print(corrector.trace_one(scores[0]))


if __name__ == "__main__":
    main()

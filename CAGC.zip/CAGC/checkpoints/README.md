# Checkpoints

Trained encoder checkpoints, linear probe weights, processed text embeddings, and cached experiment artifacts are intentionally not included. These files will be released after the paper is accepted. Keep local checkpoint paths in private configuration copies.
